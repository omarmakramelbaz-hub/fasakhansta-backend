@extends('admin.index')
@push('custom-css')
    <style type="text/css">
        .hidden {
            display: none;
        }
        .trans{
            border: 1px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: .5rem;
            background: #fff;
            padding: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .wallet{
            display: flex;
            -webkit-box-pack: justify; /* wkhtmltopdf uses this one */
            -webkit-justify-content: space-between;
            justify-content: space-between;
            -webkit-align-items: center;
            align-items: center;
            gap: 30px;
            text-align: center;
            font-weight: bold;
            border-radius: 10px;
            height: calc(100% - 40px);
            padding: 14px;
            background: #fff;
            box-shadow: 0 0 1px rgba(0, 0, 0, 0.125), 0 1px 3px rgba(0, 0, 0, 0.2);
        }
        .wallet img{
          width: 250px;
          align-self: end;
        }
        
        .wallet button{
            min-width: unset;
        }
        .select2-container {
            width: 100% !important;
        }
    </style>
@endpush
@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row justify-content-between align-items-center gy-2 mb-2">
                    <div class="col-auto">
                        <h1 class="m-0 text-dark">{{trans('main.balance')}}</h1>
                    </div><!-- /.col -->
                    {{--<div class="col-auto">
                        <ol class="breadcrumb float-sm-left">
                            {{$data['balance']}} @lang('main.egp')
                        </ol>
                    </div>--}}<!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                @include('admin.layouts.alerts')
                <div class="row gy-3 mb-3">
                    <div class="col-md-6">
                        <h5 class="fw-bold mb-3">اشحن المحفظة</h5>
                        <div class="wallet text-start">
                            <form class="w-100" method="post" action="{{ route('vendor.charging_wallet') }}">
                                    @csrf
                                    <div class="row align-items-end">
                                    <div class="col-sm-4">
                                        <label>ادخل المبلغ</label>
                                        <input class="form-control" type="number" required value="{{request('amount')}}" name="amount" min="1" max="5000">
                                    </div>
                                    <div class="col-sm-5">
                                        <label>طريقة الدفع</label>
                                        <select class="form-select" name="payment_method" required>
                                            <option value="">@lang('main.choose')</option>
                                            <option value="online">@lang('main.visa')</option>
                                            <option value="v_cash">@lang('main.v_cash')</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" class="btn btn-success w-100">@lang('main.save')</button>
                                    </div>
                                    </div>
                                </form>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h5 class="fw-bold mb-3">رصيدي</h5>
                        <div class="wallet" style="padding-bottom: 0px">
                                    <div style="flex-grow: 1;font-size: larger;">
                                        <h4 class="fw-bold">{{$data['balance']}} @lang('main.egp')</h4>
                                    </div>
                                    <img src="https://backend.smartvision4p.com/faskhaNinja/public/site/images/wallet.svg">
                                </div>
                    </div>
                </div>
                
                @forelse($wallet as $record)
                <div class="trans">
                    <span>
                    <i class="fa-solid fa-money-bill-transfer me-2"></i>
                     تم {{$record->type}} مبلغ قيمته {{$record->amount}} ج.م عن طريق {{$record->payment}} 
                    </span>
                    <span>
                        {{$record->created_at->format('Y/m/d')}}
                    </span>
                </div>
                @empty
                        {{ trans('main.empty data') }}
                @endforelse
            </div>
        </section>
    </div>
@endsection
