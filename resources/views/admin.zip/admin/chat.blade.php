<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Chat App</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    <link href="{{ url('/chat') }}/bootstrap-4.3.1.min.css" rel="stylesheet" />
    <link href="{{ url('/chat') }}/style.css" rel="stylesheet" />
</head>
<body>
    <span class="top"></span>

    <div class="container-fluid bg-white chatbox shadow-lg rounded">
        <div class="row h-100">
            <div class="col-md-4 pr-0 d-none d-md-block" id="side-1">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-1 col-sm-1 col-md-1 d-md-none">
                                <i class="fas fa-arrow-left d-md-none" style="font-size:20px;cursor:pointer;" onclick="hideChatList()"></i>
                            </div>
                            <div class="col-7 col-sm-7 col-md-7">
                                <img id="imgProfile" src="images/pp.png" class="rounded-circle profile-pic" />
                            </div>
                            <div class="col-2 col-sm-2 col-md-2">
                                <a href="#" style="float:right;" data-toggle="modal" data-target="#modalNotificationList" onclick="PopulateNotifications()">
                                    <i class="fas fa-bell icon">
                                    </i>
                                    <span id="notification">0</span>
                                </a>

                                <div class="modal fade" id="modalNotificationList">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="card">
                                                <div class="card-header">
                                                    All Users Requests
                                                    <span class="close" data-dismiss="modal" style="cursor:pointer;">&times;</span>
                                                </div>
                                                <ul class="list-group list-group-flush" id="lstNotification"></ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-2 col-sm-2 col-md-2">
                                <div class="dropleft">
                                    <span class="dropdown-toggle" data-toggle="dropdown" style="float:right">
                                        <i class="fas fa-ellipsis-v icon" style="cursor:pointer;" onclick="hideChatList()"></i>
                                    </span>
                                    <div class="dropdown-menu">
                                        <a href="#" class="dropdown-item" id="lnk" onclick="PopulateUserList()" data-toggle="modal" data-target="#modalUserList">All Users</a>
                                        <a href="#" class="dropdown-item" id="lnkNewChat" onclick="PopulateFriendList()" data-toggle="modal" data-target="#modalFriendList">New Chat</a>
                                        <a href="#" id="lnkSignIn" onclick="signIn()" class="dropdown-item">Sign In</a>
                                        <a href="#" id="lnkSignOut" onclick="signOut()" class="dropdown-item" style="display:none;">Sign Out</a>
                                    </div>

                                    <div class="modal fade" id="modalFriendList">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="card">
                                                    <div class="card-header">
                                                        Friend List
                                                        <span class="close" data-dismiss="modal" style="cursor:pointer;">&times;</span>
                                                    </div>
                                                    <ul class="list-group list-group-flush" id="lstFriend"></ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="modalUserList">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="card">
                                                    <div class="card-header">
                                                        All Users list
                                                        <span class="close" data-dismiss="modal" style="cursor:pointer;">&times;</span>
                                                    </div>
                                                    <ul class="list-group list-group-flush" id="lstUsers"></ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <ul class="list-group list-group-flush" id="lstChat"></ul>
                </div>
            </div>
            <div class="col-md-8 pl-0" id="side-2">
                <div id="chatPanel" class="card" style="display:none;">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-1 col-sm-1 col-md-1 col-lg-1 d-md-none">
                                <i class="fas fa-list mt-2" style="cursor:pointer" onclick="showChatList()"></i>
                            </div>
                            <div class="col-2 col-sm-2 col-md-2 col-lg-1">
                                <img src="images/pp.png" id="imgChat" class="rounded-circle profile-pic" />
                            </div>
                            <div class="col-5 col-sm-5 col-md-5 col-lg-7">
                                <div class="name" id="divChatName">Any Name</div>
                                <div class="under-name" id="divChatSeen">Last seen 9/8/2019</div>
                            </div>
                            <div class="col-4 col-sm-4 col-md-4 col-lg-3 icon">
                                <i class="fas fa-search"></i>
                                <span class="dropdown">
                                    <span class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fas fa-paperclip ml-4"></i>
                                    </span>
                                    <div class="dropdown-menu">
                                        <a href="#" class="dropdown-item" onclick="ChooseImage()">
                                            Image
                                            <input type="file" id="imageFile" onchange="SendImage(this);" accept="image/*" style="display:none;" />
                                        </a>
                                        <a href="#" class="dropdown-item">Document</a>
                                        <a href="#" class="dropdown-item">Camera</a>
                                        <a href="#" class="dropdown-item">Video</a>
                                    </div>
                                </span>

                                <i class="fas fa-ellipsis-v ml-4"></i>
                            </div>
                        </div>
                    </div>
                    <div class="card-body" id="messages">

                    </div>

                    <div class="card-footer">
                        <div class="row" style="position:relative;">
                            <div class="col-md-12" id="emoji" style="display:none;">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#smiley" role="tab" aria-controls="home" aria-selected="true">Smiley</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Shape</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Contact</a>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="smiley" role="tabpanel" aria-labelledby="home-tab">

                                    </div>
                                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
                                    <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-2 col-md-1" style="cursor:pointer;">
                                <i class="far fa-grin fa-2x" onclick="showEmojiPanel()"></i>
                            </div>
                            <div class="col-8 col-md-10">
                                <input id="txtMessage" onkeyup="ChangeSendIcon(this)" type="text" onfocus="hideEmojiPanel()" placeholder="Type here" class="form-control form-rounded" />
                            </div>
                            <div class="col-2 col-md-1">
                                <i style="cursor:pointer;" id="audio" onclick="record(this)" class="fas fa-microphone fa-2x"></i>
                                <i id="send" class="fa fa-paper-plane fa-2x" style="display:none"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="divStart" class="text-center">
                    <i class="fas fa-comments mt-5" style="font-size:250px;"></i>
                    <h2 class="mt-3">Select your friend from the list and start chating.</h2>
                    <a href="#" onclick="showChatList()" class="d-md-none">New Chat</a>
                    <button onclick="signIn()" class="btn btn-primary">Sign In</button>
                    <button onclick="signOut()" class="btn btn-primary">Sign Out</button>
                </div>
            </div>
        </div>
    </div>


 <script src="{{ url('/chat') }}/jquery-3.4.1.min.js"></script>
    <script src="{{ url('/chat') }}/popper-1.14.7.min.js"></script>
    <script src="{{ url('/chat') }}/bootstrap-4.3.1.min.js"></script>
  <script src="https://www.gstatic.com/firebasejs/6.4.2/firebase.js"></script>
    <script src="{{ url('/chat') }}/firebase-messaging.js"></script>
    <script src="{{ url('/chat') }}/firebase.init.js"></script>
    <script src="{{ url('/') }}/chat/chat.js"></script>
    
</body>
</html>
